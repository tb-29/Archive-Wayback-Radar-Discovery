=== Archive Radar Image Processor ===
Contributors: arsivradar
Tags: archive.org, images, import, media
Requires at least: 5.0
Tested up to: 6.4
Stable tag: 1.9.0
Requires PHP: 7.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Archive.org'dan gelen resimleri otomatik olarak indirip WordPress'e yükler ve URL'leri günceller.

== Description ==

Bu eklenti, Archive.org'dan WordPress'e aktarılan içeriklerdeki resimleri otomatik olarak işler:

* Archive.org URL'lerini tespit eder
* Resimleri indirir ve WordPress medya kütüphanesine yükler
* İçerikteki URL'leri günceller
* Batch işleme ile performans optimizasyonu
* Detaylı log sistemi
* Güvenli işleme (nonce kontrolü)

== Installation ==

1. Eklenti dosyalarını `/wp-content/plugins/archive-radar-image-processor/` klasörüne yükleyin
2. WordPress yönetici panelinde Eklentiler sayfasından eklentiyi etkinleştirin
3. Araçlar > Archive Image Processor menüsünden eklentiyi kullanın

== Usage ==

1. WordPress yönetici panelinde "Araçlar > Archive Image Processor" menüsüne gidin
2. Ayarları yapılandırın:
   - Maksimum Resim Sayısı: Bir seferde işlenecek maksimum resim sayısı
   - Batch Boyutu: Her batch'te işlenecek resim sayısı
   - Zaman Aşımı: Her resim için maksimum bekleme süresi
3. "Resimleri İşle" butonuna tıklayın
4. İşlem durumunu takip edin

== Frequently Asked Questions ==

= Hangi resim formatları desteklenir? =

JPG, JPEG, PNG, GIF ve WebP formatları desteklenir.

= İşlem ne kadar sürer? =

Resim sayısına ve boyutlarına bağlı olarak değişir. Batch işleme sayesinde büyük miktarda resim güvenli şekilde işlenebilir.

= İşlem sırasında hata olursa ne olur? =

Hata alınan resimler atlanır ve log'da gösterilir. Diğer resimler normal şekilde işlenmeye devam eder.

= Resimler nereye yüklenir? =

Resimler WordPress'in standart medya kütüphanesine yüklenir ve wp-content/uploads/ klasöründe saklanır.

== Changelog ==

= 1.0.0 =
* İlk sürüm
* Archive.org resim indirme ve yükleme
* Batch işleme sistemi
* Detaylı log sistemi
* WordPress medya kütüphanesi entegrasyonu

= 1.9.0 =
* Toplu resim işleme sırasında hatalı resimler atlanıyor, işlem durmuyor.
* Hatalı resimler ve neden işlenemediği logda detaylı gösteriliyor.
* Daha kararlı toplu işleme desteği.

== Upgrade Notice ==

= 1.0.0 =
İlk sürüm - Archive.org resim işleme özelliği eklendi. 