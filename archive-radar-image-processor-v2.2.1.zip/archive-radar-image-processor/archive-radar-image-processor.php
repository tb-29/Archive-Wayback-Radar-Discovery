<?php
/**
 * Plugin Name: Archive Radar Image Processor
 * Plugin URI: https://github.com/arsivradar
 * Description: Archive.org'dan WordPress'e aktarılan içeriklerdeki görselleri otomatik indirip medya kütüphanesine kaydeder. Archive.org linklerini temizler, toplu slug düzeltme, özet temizleme ve gelişmiş içerik yönetimi özellikleri sunar. Archive.org'dan gelen tüm linkleri orijinal adresine döndürür, sosyal paylaşım linklerini korur ve içerik kalitesini artırır.
 * Version: 2.2.0
 * Requires at least: 5.0
 * Tested up to: 6.4
 * Requires PHP: 7.4
 * Author: Archive Radar Team
 * Author URI: https://github.com/arsivradar
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: archive-radar-image-processor
 * Domain Path: /languages
 * Network: false
 * 
 * @package ArchiveRadarImageProcessor
 * @version 2.2.0
 * @author Archive Radar Team
 * @license GPL v2 or later
 */

// Güvenlik kontrolü
if (!defined('ABSPATH')) {
    exit;
}

class ArchiveRadarImageProcessor {
    
    public function __construct() {
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('wp_ajax_process_archive_images', array($this, 'process_archive_images'));
        add_action('wp_ajax_clean_internal_links', array($this, 'clean_internal_links'));
        add_action('wp_ajax_bulk_find_replace', array($this, 'bulk_find_replace'));
        add_action('wp_ajax_reset_processing', array($this, 'reset_processing'));
        add_action('wp_ajax_fix_post_slugs', array($this, 'fix_post_slugs'));
        add_action('wp_ajax_clear_post_excerpts', array($this, 'clear_post_excerpts'));
        
        // Eklenti aktif olduğunda varsayılan resmi yükle
        register_activation_hook(__FILE__, array($this, 'activate_plugin'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate_plugin'));
    }
    
    public function activate_plugin() {
        $this->upload_default_image();
    }
    
    public function deactivate_plugin() {
        // İsteğe bağlı: Varsayılan resmi sil
        // $this->remove_default_image();
    }
    
    private function get_resimyok_attachment() {
        $args = array(
            'post_type'      => 'attachment',
            'title'          => 'resim-yok',
            'posts_per_page' => 1,
            'post_status'    => 'inherit',
        );
        $query = new WP_Query($args);
        if ($query->have_posts()) {
            return $query->posts[0];
        }
        return false;
    }
    
    private function upload_default_image() {
        // Varsayılan resim zaten yüklenmiş mi kontrol et
        $existing_attachment = $this->get_resimyok_attachment();
        if ($existing_attachment) {
            return $existing_attachment->ID;
        }
        
        // Eklenti klasöründeki resim-yok.gif dosyasını yükle
        $plugin_dir = plugin_dir_path(__FILE__);
        $default_image_path = $plugin_dir . 'resim-yok.gif';
        
        if (!file_exists($default_image_path)) {
            return false;
        }
        
        // Dosyayı WordPress'e yükle
        $upload = wp_upload_bits('resim-yok.gif', null, file_get_contents($default_image_path));
        
        if ($upload['error']) {
            return false;
        }
        
        // Medya kütüphanesine ekle
        $attachment_id = wp_insert_attachment(array(
            'post_title' => 'resim-yok',
            'post_content' => 'Varsayılan resim - Archive.org\'dan indirilemeyen resimler için',
            'post_status' => 'inherit',
            'post_mime_type' => 'image/gif'
        ), $upload['file']);
        
        if (is_wp_error($attachment_id)) {
            return false;
        }
        
        // Resim boyutlarını oluştur
        require_once(ABSPATH . 'wp-admin/includes/image.php');
        $attachment_data = wp_generate_attachment_metadata($attachment_id, $upload['file']);
        wp_update_attachment_metadata($attachment_id, $attachment_data);
        
        return $attachment_id;
    }
    
    private function remove_default_image() {
        $attachment = $this->get_resimyok_attachment();
        if ($attachment) {
            wp_delete_attachment($attachment->ID, true);
        }
    }
    
    private function get_default_image_url() {
        // Varsayılan resim attachment'ını bul
        $attachment = $this->get_resimyok_attachment();
        if ($attachment) {
            return wp_get_attachment_url($attachment->ID);
        }
        
        // Bulunamazsa yükle
        $attachment_id = $this->upload_default_image();
        if ($attachment_id) {
            return wp_get_attachment_url($attachment_id);
        }
        
        return false;
    }
    
    public function add_admin_menu() {
        add_management_page(
            'Archive Radar Image Processor',
            'Archive Image Processor',
            'manage_options',
            'archive-radar-image-processor',
            array($this, 'admin_page')
        );
    }
    
    public function admin_page() {
        // Toplam resim sayısını hesapla
        $total_images = $this->count_archive_images();
        $total_internal_links = $this->count_internal_links();
        
        // Varsayılan resim durumunu kontrol et
        $default_image_status = $this->get_default_image_url() ? '✅ Yüklü' : '❌ Yüklenmedi';
        ?>
        <div class="wrap">
            <style>
                body, .wrap {
                    font-family: 'Segoe UI', 'Roboto', 'Arial', sans-serif;
                    background: #f6f8fa;
                }
                .arip-header {
                    background: #fff;
                    border-radius: 12px;
                    box-shadow: 0 2px 8px rgba(0,0,0,0.06);
                    padding: 32px 32px 18px 32px;
                    margin-bottom: 32px;
                    border: 1px solid #e0e0e0;
                    text-align: center;
                }
                .arip-header h1 {
                    margin: 0 0 10px 0;
                    font-size: 2rem;
                    letter-spacing: 0.5px;
                }
                .arip-header p {
                    margin: 0;
                    color: #555;
                    font-size: 1.08rem;
                }
                .arip-tabs {
                    display: flex;
                    border-bottom: 2px solid #e0e0e0;
                    margin-bottom: 24px;
                    background: #fff;
                    border-radius: 10px 10px 0 0;
                    overflow-x: auto;
                }
                .arip-tab {
                    padding: 14px 28px 12px 28px;
                    cursor: pointer;
                    font-size: 1.08rem;
                    color: #555;
                    border: none;
                    background: none;
                    outline: none;
                    transition: color 0.2s, background 0.2s;
                    margin-right: 2px;
                }
                .arip-tab.active {
                    color: #0073aa;
                    border-bottom: 3px solid #0073aa;
                    background: #f6f8fa;
                    font-weight: bold;
                }
                .arip-tab-content {
                    display: none;
                }
                .arip-tab-content.active {
                    display: block;
                }
                .arip-card {
                    background: #fff;
                    border-radius: 12px;
                    box-shadow: 0 2px 8px rgba(0,0,0,0.07);
                    border: 1px solid #e0e0e0;
                    padding: 26px 22px 20px 22px;
                    width: 100%;
                    margin: 0 auto 32px auto;
                    max-width: 600px;
                    min-width: 0;
                    display: flex;
                    flex-direction: column;
                    justify-content: space-between;
                }
                .arip-card h2 {
                    margin-top: 0;
                    font-size: 1.18rem;
                    margin-bottom: 14px;
                    color: #222;
                }
                .arip-card table.form-table {
                    width: 100%;
                    margin-bottom: 0;
                }
                .arip-card button.button {
                    margin-top: 8px;
                }
                .arip-card p {
                    margin-bottom: 10px;
                }
                .arip-log-container {
                    max-height: 200px;
                    overflow-y: auto;
                    background: #f9f9f9;
                    padding: 10px;
                    margin: 10px 0;
                    font-family: monospace;
                    font-size: 12px;
                    border-radius: 6px;
                    border: 1px solid #ececec;
                }
                @media (max-width: 700px) {
                    .arip-card { max-width: 100%; padding: 12px 4vw; }
                    .arip-tabs { flex-wrap: wrap; }
                    .arip-tab { padding: 10px 10px; font-size: 1rem; }
                }
            </style>
            <div class="arip-header">
                <h1>Archive Radar Image Processor</h1>
                <p>Archive.org'dan gelen görselleri indirip, kendi sitenize kaydeder ve kalan archive.org linklerini temizler. Ayrıca toplu slug düzeltme ve diğer gelişmiş işlemler.</p>
            </div>
            <div class="arip-tabs">
                <button class="arip-tab active" data-tab="durum">Durum</button>
                <button class="arip-tab" data-tab="resim">Resim İşleme</button>
                <button class="arip-tab" data-tab="link">İç Link Temizleme</button>
                <button class="arip-tab" data-tab="replace">Bul & Değiştir</button>
                <button class="arip-tab" data-tab="ayar">Ayarlar</button>
                <button class="arip-tab" data-tab="slug">Slug Düzelt</button>
            </div>
            <div class="arip-tab-content active" id="tab-durum">
                <div class="arip-card">
                    <h2>Durum Bilgileri</h2>
                    <p style="color:#555; margin-bottom:18px;">Eklentinin genel durumu ve tespit edilen içeriklerin özetini burada görebilirsin.</p>
                    <table class="form-table">
                        <tr>
                            <th>Varsayılan Resim:</th>
                            <td><?php echo $default_image_status; ?> <span style="color:#888; font-size:12px;">(İndirilemeyen görseller için kullanılır)</span></td>
                        </tr>
                        <tr>
                            <th>Tespit Edilen Resim:</th>
                            <td><?php echo $total_images; ?> adet <span style="color:#888; font-size:12px;">(archive.org kaynaklı)</span></td>
                        </tr>
                        <tr>
                            <th>Tespit Edilen İç Link:</th>
                            <td><?php echo $total_internal_links; ?> adet <span style="color:#888; font-size:12px;">(archive.org linkleri)</span></td>
                        </tr>
                    </table>
                </div>
                
                <?php if ($total_images > 0): ?>
                <div class="arip-card">
                    <h2>📊 Detaylı Analiz</h2>
                    <p style="color:#555; margin-bottom:18px;">Archive.org linkleri içeren gönderilerin detaylı listesi:</p>
                    <div style="max-height: 400px; overflow-y: auto; background: #f9f9f9; padding: 15px; border-radius: 6px; font-family: monospace; font-size: 12px;">
                        <?php 
                        $analysis = $this->get_detailed_archive_analysis();
                        if (!empty($analysis)) {
                            foreach ($analysis as $item) {
                                echo "<div style='margin-bottom: 15px; padding: 10px; background: #fff; border-radius: 4px; border-left: 4px solid #0073aa;'>";
                                echo "<strong>📝 Gönderi #{$item['id']}: {$item['title']}</strong><br>";
                                echo "<span style='color: #666;'>🔗 {$item['count']} archive.org linki bulundu:</span><br>";
                                foreach ($item['links'] as $link) {
                                    echo "<span style='color: #d63384;'>• " . htmlspecialchars($link) . "</span><br>";
                                }
                                echo "</div>";
                            }
                        } else {
                            echo "<div style='color: #28a745;'>✅ Tüm archive.org linkleri temizlendi!</div>";
                        }
                        ?>
                    </div>
                </div>
                <?php endif; ?>
            </div>
            <div class="arip-tab-content" id="tab-resim">
                <div class="arip-card">
                    <h2>🖼️ Resim İşleme</h2>
                    <p style="color:#555; margin-bottom:18px;">Archive.org'dan gelen görselleri indirip, kendi sitenize kaydeder. <br><b>İpucu:</b> Büyük sitelerde <b>Batch Boyutu</b> 1 seçilmesi önerilir. Timeout hatası alırsanız <b>Zaman Aşımı</b> süresini artırın.</p>
                    <ul style="color:#666; font-size:13px; margin-bottom:18px;">
                        <li>Her işlemde sadece seçtiğiniz kadar görsel işlenir.</li>
                        <li>İşlem sırasında ilerleme ve loglar ekranda gösterilir.</li>
                        <li>İndirilemeyen görseller otomatik olarak varsayılan resimle değiştirilir.</li>
                        <li>İşlem tamamlanınca özet bilgi ve başarı oranı gösterilir.</li>
                    </ul>
                    <div id="processing-status">Hazır</div>
                    <div id="processing-progress" style="display:none;">
                        <div class="progress-bar" style="width: 100%; height: 20px; background: #f0f0f0; border: 1px solid #ccc;">
                            <div id="progress-fill" style="width: 0%; height: 100%; background: #0073aa; transition: width 0.3s;"></div>
                        </div>
                        <div id="progress-text">0%</div>
                    </div>
                    
                    <div id="log-container" style="max-height: 400px; overflow-y: auto; background: #f9f9f9; padding: 10px; margin: 10px 0; font-family: monospace; font-size: 12px; display: none;">
                        <div id="log-content"></div>
                    </div>
                    
                    <p>
                        <button id="process-images" class="button button-primary">🚀 Resimleri İşle</button>
                        <button id="stop-processing" class="button button-secondary" style="display:none;">⏹️ Durdur</button>
                        <button id="reset-processing" class="button button-secondary">🔄 İşlemi Sıfırla</button>
                    </p>
                    
                    <div id="patience-message" style="display:none; background: #fff3cd; border: 1px solid #ffeaa7; padding: 10px; margin: 10px 0; border-radius: 4px;">
                        <strong>⏳ Lütfen sabırlı olun!</strong> İşlem devam ediyor. Bu işlem resim sayısına bağlı olarak uzun sürebilir. Sayfayı kapatmayın.
                    </div>
                </div>
            </div>
            <div class="arip-tab-content" id="tab-link">
                <div class="arip-card">
                    <h2>🔗 İç Link Temizleme</h2>
                    <p style="color:#555; margin-bottom:18px;">Archive.org linklerini temizler ve site içi linkleri düzeltir. <br><b>Uyarı:</b> Bu işlem geri alınamaz, yedek almanız önerilir.</p>
                    <ul style="color:#666; font-size:13px; margin-bottom:18px;">
                        <li>Archive.org ile başlayan tüm <code>&lt;a href&gt;</code> linkleri orijinal adresine döner.</li>
                        <li>İşlem sonrası kaç linkin temizlendiği logda gösterilir.</li>
                        <li>İşlem bittikten sonra sayfayı yenilemeniz önerilir.</li>
                    </ul>
                    <p><strong>Tespit edilen iç link sayısı:</strong> <?php echo $total_internal_links; ?></p>
                    <p>
                        <button id="clean-links" class="button button-secondary">🔄 İç Linkleri Temizle</button>
                        <button id="clear-excerpts" class="button button-secondary" style="margin-left:12px;">📝 Özetleri Temizle</button>
                    </p>
                    <div style="background: #f9f9f9; padding: 15px; border-radius: 6px; margin: 15px 0; border-left: 4px solid #0073aa;">
                        <h4 style="margin: 0 0 10px 0; color: #0073aa;">🔧 Buton Açıklamaları:</h4>
                        <p style="margin: 5px 0; font-size: 13px;"><strong>🔄 İç Linkleri Temizle:</strong> Yazıların içindeki tüm archive.org (wayback) linklerini bulur ve orijinal adresine döndürür. <b>Kırık veya tamamlanmamış archive.org linkleri de otomatik olarak silinir.</b> Örneğin: <code>https://web.archive.org/web/20200101/http://example.com</code> → <code>http://example.com</code></p>
                        <p style="margin: 5px 0; font-size: 13px;"><strong>📝 Özetleri Temizle:</strong> Tüm yazıların özet (excerpt) alanını boşaltır. Archive.org'dan aktarılan yazılarda genellikle gereksiz veya boş özetler bulunur, bu butonla toplu olarak temizlenir.</p>
                    </div>
                    <div id="link-log-container" style="max-height: 200px; overflow-y: auto; background: #f9f9f9; padding: 10px; margin: 10px 0; font-family: monospace; font-size: 12px; display: none;">
                        <div id="link-log-content"></div>
                    </div>
                </div>
            </div>
            <div class="arip-tab-content" id="tab-replace">
                <div class="arip-card">
                    <h2>🔍 Bul ve Değiştir</h2>
                    <p style="color:#555; margin-bottom:18px;">Veritabanındaki tüm içeriklerde toplu metin değiştirme yapar. <br><b>Uyarı:</b> Bu işlem geri alınamaz, dikkatli kullanın!</p>
                    <ul style="color:#666; font-size:13px; margin-bottom:18px;">
                        <li>Yazılar, sayfalar ve yorumlarda toplu arama & değiştirme yapılabilir.</li>
                        <li>İşlem sonrası kaç kaydın güncellendiği logda gösterilir.</li>
                        <li>Yedek almadan toplu değişiklik yapmayın.</li>
                    </ul>
                    
                    <table class="form-table">
                        <tr>
                            <th>Bul:</th>
                            <td>
                                <input type="text" id="find-text" placeholder="Değiştirilecek metin" style="width: 300px;">
                            </td>
                        </tr>
                        <tr>
                            <th>Değiştir:</th>
                            <td>
                                <input type="text" id="replace-text" placeholder="Yeni metin" style="width: 300px;">
                            </td>
                        </tr>
                        <tr>
                            <th>Kapsam:</th>
                            <td>
                                <label><input type="checkbox" id="replace-posts" checked> Yazılar</label><br>
                                <label><input type="checkbox" id="replace-pages" checked> Sayfalar</label><br>
                                <label><input type="checkbox" id="replace-comments" checked> Yorumlar</label>
                            </td>
                        </tr>
                    </table>
                    
                    <p>
                        <button id="find-replace" class="button button-secondary">Bul ve Değiştir</button>
                    </p>
                    
                    <div id="replace-log-container" style="max-height: 200px; overflow-y: auto; background: #f9f9f9; padding: 10px; margin: 10px 0; font-family: monospace; font-size: 12px; display: none;">
                        <div id="replace-log-content"></div>
                    </div>
                </div>
            </div>
            <div class="arip-tab-content" id="tab-ayar">
                <div class="arip-card">
                    <h2>⚙️ Ayarlar</h2>
                    <p style="color:#555; margin-bottom:18px;">Eklentinin çalışma parametrelerini buradan ayarlayabilirsin. <br><b>İpucu:</b> Sunucunuz yavaşsa batch boyutunu düşük tutun.</p>
                    <ul style="color:#666; font-size:13px; margin-bottom:18px;">
                        <li>Maksimum resim sayısı, batch boyutu ve zaman aşımı ayarlanabilir.</li>
                        <li>Her değişiklikten sonra işlemi baştan başlatmanız gerekebilir.</li>
                    </ul>
                    <table class="form-table">
                        <tr>
                            <th>Maksimum Resim Sayısı</th>
                            <td>
                                <input type="number" id="max-images" value="<?php echo $total_images; ?>" min="1" max="1000">
                                <p class="description">Bir seferde işlenecek maksimum resim sayısı (Tespit edilen: <?php echo $total_images; ?> resim) - <strong>AJAX timeout olmaması için tüm resimleri işleyin</strong></p>
                            </td>
                        </tr>
                        <tr>
                            <th>Batch Boyutu</th>
                            <td>
                                <input type="number" id="batch-size" value="1" min="1" max="50">
                                <p class="description">
                                    <strong>Batch Boyutu:</strong> Her işlemde kaç resim işleneceğini belirler.<br>
                                    <strong>Önerilen:</strong> Sunucunuz yavaşsa veya çok resim varsa <b>1</b> seçin.<br>
                                    <strong>Örnek:</strong> 1 seçerseniz, eklenti her seferinde 1 resmi indirir ve işler. Timeout hatası riskiniz azalır.<br>
                                    <strong>Not:</strong> Büyük sitelerde veya paylaşımlı hostingde <b>1</b> en güvenli değerdir.
                                </p>
                            </td>
                        </tr>
                        <tr>
                            <th>Zaman Aşımı (saniye)</th>
                            <td>
                                <input type="number" id="timeout" value="300" min="30" max="600">
                                <p class="description">
                                    <strong>Zaman Aşımı (saniye):</strong> Her resim için maksimum bekleme süresi.<br>
                                    <strong>Önerilen:</strong> 300 saniye (5 dakika) - AJAX timeout olmaması için.<br>
                                    <strong>Örnek:</strong> 300 seçerseniz, her resmin indirilmesi için 5 dakika beklenir. Büyük resimlerde faydalıdır.<br>
                                    <strong>Not:</strong> 40+ resim varsa kesinlikle 300+ kullanın!
                                </p>
                            </td>
                        </tr>
                    </table>
                </div>
            </div>
            <div class="arip-tab-content" id="tab-slug">
                <div class="arip-card">
                    <h2>🔗 Yazı URL'lerini Düzelt</h2>
                    <p style="color:#555; margin-bottom:18px;">Tüm yazıların URL'sini (slug) başlıktan otomatik olarak oluşturur. <br><b>Örnek:</b> <i>archive-post-31</i> → <i>htc-one-m9-tanitildi-iste-ozellikleri-ve-detaylari</i></p>
                    <ul style="color:#666; font-size:13px; margin-bottom:18px;">
                        <li>Yalnızca değişmesi gereken slug'lar güncellenir.</li>
                        <li>Her değişiklik için log ekranda gösterilir.</li>
                        <li>İşlem geri alınamaz, yedek almanız önerilir.</li>
                    </ul>
                    <button id="fix-slugs" class="button button-secondary">Yazı URL'lerini Düzelt</button>
                    <div id="slug-log-container" class="arip-log-container" style="display: none;">
                        <div id="slug-log-content"></div>
                    </div>
                </div>
            </div>
        </div>
        
        <script>
        // Sekme geçişi için vanilla JS (jQuery'ye gerek yok)
        document.addEventListener('DOMContentLoaded', function() {
            var tabs = document.querySelectorAll('.arip-tab');
            var tabContents = document.querySelectorAll('.arip-tab-content');
            tabs.forEach(function(tab) {
                tab.addEventListener('click', function() {
                    tabs.forEach(function(t) { t.classList.remove('active'); });
                    tabContents.forEach(function(tc) { tc.classList.remove('active'); });
                    tab.classList.add('active');
                    document.getElementById('tab-' + tab.getAttribute('data-tab')).classList.add('active');
                });
            });
        });
        jQuery(document).ready(function($) {
            let isProcessing = false;
            let currentBatch = 0;
            let totalProcessed = 0;
            let totalImages = <?php echo $total_images; ?>;
            let startTime = null;
            
            // Resim İşleme
            $('#process-images').click(function() {
                if (isProcessing) return;
                
                isProcessing = true;
                currentBatch = 0;
                totalProcessed = 0;
                startTime = new Date();
                
                $('#process-images').hide();
                $('#stop-processing').show();
                $('#processing-progress').show();
                $('#log-container').show();
                $('#patience-message').show();
                $('#log-content').html('');
                
                const maxImages = parseInt($('#max-images').val());
                const batchSize = parseInt($('#batch-size').val());
                const timeout = parseInt($('#timeout').val());
                
                log('🚀 İşlem başlatılıyor...', 'success');
                log(`📊 Ayarlar: Maksimum ${maxImages} resim, Batch boyutu: ${batchSize}, Timeout: ${timeout}s`);
                log('⏳ Lütfen sabırlı olun! Bu işlem resim sayısına bağlı olarak uzun sürebilir.', 'info');
                log('💡 İpucu: Sayfayı kapatmayın, işlem arka planda devam ediyor.', 'info');
                
                processBatch();
                
                function processBatch() {
                    if (!isProcessing) return;
                    
                    const batchStartTime = new Date();
                    
                    $.ajax({
                        url: ajaxurl,
                        type: 'POST',
                        data: {
                            action: 'process_archive_images',
                            batch: currentBatch,
                            batch_size: batchSize,
                            max_images: maxImages,
                            timeout: timeout,
                            nonce: '<?php echo wp_create_nonce("archive_radar_nonce"); ?>'
                        },
                        success: function(response) {
                            if (response.success) {
                                const data = response.data;
                                const batchEndTime = new Date();
                                const batchDuration = Math.round((batchEndTime - batchStartTime) / 1000);
                                
                                totalProcessed += data.processed;
                                totalImages = data.total_images;
                                
                                log(`✅ Batch ${currentBatch + 1} tamamlandı (${batchDuration}s): ${data.processed} gönderi işlendi`, 'success');
                                
                                if (data.logs) {
                                    data.logs.forEach(logEntry => {
                                        log(logEntry, data.log_type || 'info');
                                    });
                                }
                                
                                // Tahmini kalan süre hesapla
                                if (currentBatch > 0) {
                                    const avgBatchTime = Math.round((new Date() - startTime) / 1000 / currentBatch);
                                    const remainingBatches = Math.ceil((totalImages - totalProcessed) / batchSize);
                                    const estimatedTime = Math.round(avgBatchTime * remainingBatches / 60);
                                    
                                    if (estimatedTime > 0) {
                                        log(`⏱️ Tahmini kalan süre: ~${estimatedTime} dakika`, 'info');
                                    }
                                }
                                
                                updateProgress(data.progress || 0);
                                
                                if (data.completed || totalProcessed >= maxImages) {
                                    completeProcessing();
                                } else {
                                    currentBatch++;
                                    // Batch'ler arası daha uzun bekleme (AJAX timeout olmaması için)
                                    setTimeout(processBatch, 2000);
                                }
                            } else {
                                log('❌ Hata: ' + (response.data.message || response.data), 'error');
                                if (response.data.logs) {
                                    response.data.logs.forEach(logEntry => {
                                        log(logEntry, 'error');
                                    });
                                }
                                completeProcessing();
                            }
                        },
                        error: function(xhr, status, error) {
                            log('❌ AJAX hatası: ' + error, 'error');
                            log('📋 Detay: ' + status, 'error');
                            completeProcessing();
                        },
                        timeout: (timeout + 60) * 1000 // Timeout + 60 saniye ekstra (AJAX timeout için)
                    });
                }
                
                function updateProgress(percentage) {
                    percentage = Math.min(100, percentage); // Clamp to 100
                    $('#progress-fill').css('width', percentage + '%');
                    $('#progress-text').text(percentage + '%');

                    // Progress bar rengini güncelle
                    if (percentage >= 100) {
                        $('#progress-fill').css('background', '#28a745');
                    } else if (percentage >= 50) {
                        $('#progress-fill').css('background', '#ffc107');
                    } else {
                        $('#progress-fill').css('background', '#0073aa');
                    }
                }
                
                function completeProcessing() {
                    const endTime = new Date();
                    const totalDuration = Math.round((endTime - startTime) / 1000);
                    const minutes = Math.floor(totalDuration / 60);
                    const seconds = totalDuration % 60;
                    
                    isProcessing = false;
                    $('#process-images').show();
                    $('#stop-processing').hide();
                    $('#patience-message').hide();
                    
                    log(`🎉 İşlem tamamlandı!`, 'success');
                    log(`📊 Toplam süre: ${minutes} dakika ${seconds} saniye`, 'info');
                    log(`📝 Toplam işlenen: ${totalProcessed} gönderi`, 'info');
                    const safeSuccess = totalImages > 0 ? Math.min(100, Math.round((totalProcessed / totalImages) * 100)) : 0;
                    log(`📈 Başarı oranı: ${safeSuccess}%`, 'info');

                    // Progress bar'ı yeşil yap
                    $('#progress-fill').css('background', '#28a745');
                }
            });
            
            $('#stop-processing').click(function() {
                isProcessing = false;
                $('#process-images').show();
                $('#stop-processing').hide();
                $('#patience-message').hide();
                log('⏹️ İşlem kullanıcı tarafından durduruldu.', 'warning');
            });
            
            // Reset işlemi
            $('#reset-processing').click(function() {
                if (isProcessing) {
                    alert('İşlem devam ediyor. Önce durdurun.');
                    return;
                }
                
                if (!confirm('İşlem durumunu sıfırlamak istediğinizden emin misiniz? Bu işlem tüm işlenmiş gönderileri tekrar işleyecektir.')) {
                    return;
                }
                
                $('#reset-processing').prop('disabled', true).text('Sıfırlanıyor...');
                
                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'reset_processing',
                        nonce: '<?php echo wp_create_nonce("archive_radar_nonce"); ?>'
                    },
                    success: function(response) {
                        if (response.success) {
                            log('🔄 İşlem durumu sıfırlandı!', 'success');
                            log('📝 Artık tüm gönderiler tekrar işlenebilir.', 'info');
                            // Sayfayı yenile
                            setTimeout(function() {
                                location.reload();
                            }, 2000);
                        } else {
                            log('❌ Sıfırlama hatası: ' + response.data, 'error');
                        }
                    },
                    error: function() {
                        log('❌ Sıfırlama AJAX hatası', 'error');
                    },
                    complete: function() {
                        $('#reset-processing').prop('disabled', false).text('🔄 İşlemi Sıfırla');
                    }
                });
            });
            
            // İç Link Temizleme
            $('#clean-links').click(function() {
                if (isProcessing) return;
                
                isProcessing = true;
                $('#clean-links').prop('disabled', true).text('Temizleniyor...');
                $('#link-log-container').show();
                $('#link-log-content').html('');
                
                logLink('İç link temizleme başlatılıyor...');
                
                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'clean_internal_links',
                        nonce: '<?php echo wp_create_nonce("archive_radar_nonce"); ?>'
                    },
                    success: function(response) {
                        if (response.success) {
                            logLink(`✅ İşlem tamamlandı! ${response.data.processed} link temizlendi.`);
                            if (response.data.logs) {
                                response.data.logs.forEach(logEntry => {
                                    logLink(logEntry);
                                });
                            }
                        } else {
                            logLink('❌ Hata: ' + response.data, 'error');
                        }
                    },
                    error: function() {
                        logLink('❌ AJAX hatası oluştu', 'error');
                    },
                    complete: function() {
                        isProcessing = false;
                        $('#clean-links').prop('disabled', false).text('İç Linkleri Temizle');
                    }
                });
            });
            
            // Bul ve Değiştir
            $('#find-replace').click(function() {
                if (isProcessing) return;
                
                const findText = $('#find-text').val().trim();
                const replaceText = $('#replace-text').val().trim();
                const replacePosts = $('#replace-posts').is(':checked');
                const replacePages = $('#replace-pages').is(':checked');
                const replaceComments = $('#replace-comments').is(':checked');
                
                if (!findText) {
                    alert('Lütfen "Bul" alanını doldurun!');
                    return;
                }
                
                if (!replacePosts && !replacePages && !replaceComments) {
                    alert('Lütfen en az bir kapsam seçin!');
                    return;
                }
                
                if (!confirm(`"${findText}" metnini "${replaceText}" ile değiştirmek istediğinizden emin misiniz? Bu işlem geri alınamaz!`)) {
                    return;
                }
                
                isProcessing = true;
                $('#find-replace').prop('disabled', true).text('Değiştiriliyor...');
                $('#replace-log-container').show();
                $('#replace-log-content').html('');
                
                logReplace('Bul ve değiştir işlemi başlatılıyor...');
                
                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'bulk_find_replace',
                        find_text: findText,
                        replace_text: replaceText,
                        replace_posts: replacePosts,
                        replace_pages: replacePages,
                        replace_comments: replaceComments,
                        nonce: '<?php echo wp_create_nonce("archive_radar_nonce"); ?>'
                    },
                    success: function(response) {
                        if (response.success) {
                            logReplace(`✅ İşlem tamamlandı! ${response.data.processed} kayıt güncellendi.`);
                            if (response.data.logs) {
                                response.data.logs.forEach(logEntry => {
                                    logReplace(logEntry);
                                });
                            }
                        } else {
                            logReplace('❌ Hata: ' + response.data, 'error');
                        }
                    },
                    error: function() {
                        logReplace('❌ AJAX hatası oluştu', 'error');
                    },
                    complete: function() {
                        isProcessing = false;
                        $('#find-replace').prop('disabled', false).text('Bul ve Değiştir');
                    }
                });
            });
            
            // Yazı URL'lerini Düzelt
            $('#fix-slugs').click(function() {
                if (!confirm('Tüm yazilarin URL\'si basliktan otomatik olarak olusturulacak. Devam edilsin mi?')) return;
                $('#fix-slugs').prop('disabled', true).text('Düzeltiliyor...');
                $('#slug-log-container').show();
                $('#slug-log-content').html('');
                logSlug('🔄 İşlem başlatıldı...');
                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'fix_post_slugs',
                        nonce: '<?php echo wp_create_nonce("archive_radar_nonce"); ?>'
                    },
                    success: function(response) {
                        if (response.success) {
                            if (response.data.logs) {
                                response.data.logs.forEach(logEntry => {
                                    logSlug(logEntry);
                                });
                            }
                            logSlug('✅ Tüm yazi URL\'leri basariyla duzeltildi!');
                        } else {
                            logSlug('❌ Hata: ' + response.data, 'error');
                        }
                    },
                    error: function() {
                        logSlug('❌ AJAX hatası oluştu', 'error');
                    },
                    complete: function() {
                        $('#fix-slugs').prop('disabled', false).text('Yazı URL\'lerini Düzelt');
                    }
                });
            });

            function log(message, type = 'info') {
                const timestamp = new Date().toLocaleTimeString();
                const typeClass = type === 'error' ? 'color: red;' : 
                                type === 'success' ? 'color: green;' : 
                                type === 'warning' ? 'color: orange;' : 'color: black;';
                
                $('#log-content').append(`<div style="${typeClass}">[${timestamp}] ${message}</div>`);
                $('#log-container').scrollTop($('#log-container')[0].scrollHeight);
            }
            
            function logLink(message, type = 'info') {
                const timestamp = new Date().toLocaleTimeString();
                const typeClass = type === 'error' ? 'color: red;' : 
                                type === 'success' ? 'color: green;' : 
                                type === 'warning' ? 'color: orange;' : 'color: black;';
                
                $('#link-log-content').append(`<div style="${typeClass}">[${timestamp}] ${message}</div>`);
                $('#link-log-container').scrollTop($('#link-log-container')[0].scrollHeight);
            }
            
            function logReplace(message, type = 'info') {
                const timestamp = new Date().toLocaleTimeString();
                const typeClass = type === 'error' ? 'color: red;' : 
                                type === 'success' ? 'color: green;' : 
                                type === 'warning' ? 'color: orange;' : 'color: black;';
                
                $('#replace-log-content').append(`<div style="${typeClass}">[${timestamp}] ${message}</div>`);
                $('#replace-log-container').scrollTop($('#replace-log-container')[0].scrollHeight);
            }

            function logSlug(message, type = 'info') {
                const timestamp = new Date().toLocaleTimeString();
                const typeClass = type === 'error' ? 'color: red;' : type === 'success' ? 'color: green;' : 'color: black;';
                $('#slug-log-content').append(`<div style="${typeClass}">[${timestamp}] ${message}</div>`);
                $('#slug-log-container').scrollTop($('#slug-log-container')[0].scrollHeight);
            }

            $('#clear-excerpts').click(function() {
                if (isProcessing) return;
                if (!confirm('Tüm yazıların özet (excerpt) alanı temizlenecek. Devam edilsin mi?')) return;
                isProcessing = true;
                $('#clear-excerpts').prop('disabled', true).text('Temizleniyor...');
                $('#link-log-container').show();
                $('#link-log-content').html('');
                logLink('Özet temizleme başlatılıyor...');
                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'clear_post_excerpts',
                        nonce: '<?php echo wp_create_nonce("archive_radar_nonce"); ?>'
                    },
                    success: function(response) {
                        if (response.success) {
                            logLink(`✅ İşlem tamamlandı! ${response.data.processed} yazının özeti temizlendi.`);
                            if (response.data.logs) {
                                response.data.logs.forEach(logEntry => {
                                    logLink(logEntry);
                                });
                            }
                        } else {
                            logLink('❌ Hata: ' + response.data, 'error');
                        }
                    },
                    error: function() {
                        logLink('❌ AJAX hatası oluştu', 'error');
                    },
                    complete: function() {
                        isProcessing = false;
                        $('#clear-excerpts').prop('disabled', false).text('Özetleri Temizle');
                    }
                });
            });
        });
        </script>
        <?php
    }
    
    private function process_post_images($post, $content, $timeout, &$logs) {
        $archive_patterns = [
            '/(src|data-src|srcset)=("|\')([^"\'>]*web\.archive\.org[^"\'>]+\.(jpg|jpeg|png|gif|webp|bmp|svg)[^"\'>]*)/i',
            '/https?:\/\/web\.archive\.org\/[^"\'>\s]+\.(jpg|jpeg|png|gif|webp|bmp|svg)/i',
        ];
        $all_matches = [];
        $logs[] = "🔍 Gönderi #{$post->ID}: Archive.org resimleri aranıyor...";
        
        foreach ($archive_patterns as $pattern_index => $pattern) {
            preg_match_all($pattern, $content, $matches);
            if (!empty($matches[0])) {
                $logs[] = "📊 Pattern " . ($pattern_index + 1) . " ile " . count($matches[0]) . " resim bulundu:";
                foreach ($matches[0] as $url) {
                    $clean_url = trim($url, "'\"<>");
                    if (!in_array($clean_url, $all_matches)) {
                        $all_matches[] = $clean_url;
                        $logs[] = "   ✅ " . $clean_url;
                    } else {
                        $logs[] = "   ⚠️ Duplicate: " . $clean_url;
                    }
                }
            }
        }
        
        $logs[] = "📈 Gönderi #{$post->ID}: Toplam " . count($all_matches) . " benzersiz archive.org resmi bulundu.";
        
        $updated_content = $content;
        
        // 1. Önce resimleri işle
        if (!empty($all_matches)) {
            $archive_url = $all_matches[0];
            $logs[] = "Gönderi #{$post->ID}: " . count($all_matches) . " archive.org resmi işleniyor (garantili mod, yavaş ama timeout olmaz)";
            $failed_images = [];
            $replace_map = [];
            
            // Her durumda, indirilemeyen/bozuk linkler de dahil, archive.org linkini resim-yok.gif ile değiştir
            $new_url = $this->download_and_upload_image_safe($archive_url, $post->ID, $timeout, $logs, $failed_images);
            if (!$new_url) {
                $new_url = $this->get_default_image_url();
                $logs[] = "⚠️ $archive_url indirilemedi, resim-yok.gif ile değiştirildi.";
            }
            $replace_map[$archive_url] = $new_url;
            
            // İçerikteki bu archive.org linkini yeni URL ile değiştir
            foreach ($replace_map as $old => $new) {
                $updated_content = str_replace($old, $new, $updated_content);
            }
        } else {
            $logs[] = "Gönderi #{$post->ID}: Archive.org resmi bulunamadı.";
        }
        
        // Sadece resim işleme yap, iç link temizliğine karışma
        
        return $updated_content;
    }
    
    // process_archive_images fonksiyonunda, kalan archive.org linki varsa _archive_processed meta EKLEME
    public function process_archive_images() {
        if (!wp_verify_nonce($_POST['nonce'], 'archive_radar_nonce')) {
            wp_die('Güvenlik hatası');
        }
        $batch = intval($_POST['batch']);
        $batch_size = intval($_POST['batch_size']);
        $max_images = intval($_POST['max_images']);
        $timeout = intval($_POST['timeout']);
        $logs = array();
        $processed = 0;
        $completed = false;
        $total_images_found = 0;
        $total_images_processed = 0;
        try {
            $posts = get_posts(array(
                'post_type' => 'post',
                'post_status' => 'publish',
                'posts_per_page' => $batch_size,
                'offset' => $batch * $batch_size,
                'meta_query' => array(
                    array(
                        'key' => '_archive_processed',
                        'compare' => 'NOT EXISTS'
                    )
                ),
                'orderby' => 'ID',
                'order' => 'ASC'
            ));
            if (empty($posts)) {
                $completed = true;
                $logs[] = '🎯 İşlenecek gönderi bulunamadı. Tüm gönderiler işlenmiş olabilir.';
            } else {
                $logs[] = "📝 Batch #" . ($batch + 1) . ": " . count($posts) . " gönderi işlenecek";
                foreach ($posts as $post) {
                    if ($processed >= $max_images) {
                        $logs[] = "⏹️ Maksimum resim sayısına ulaşıldı ({$max_images})";
                        break;
                    }
                    $content = $post->post_content;
                    $logs[] = "🔍 Gönderi #{$post->ID} analiz ediliyor...";
                    $updated_content = $this->process_post_images($post, $content, $timeout, $logs);
                    $featured_image_url = get_post_meta($post->ID, '_featured_image_url', true);
                    if ($featured_image_url) {
                        $logs[] = "🖼️ Öne çıkan görsel işleniyor: " . basename($featured_image_url);
                        $attach_id = $this->download_and_attach_featured_image($featured_image_url, $post->ID, $timeout, $logs);
                        if ($attach_id) {
                            set_post_thumbnail($post->ID, $attach_id);
                            $logs[] = "✅ Öne çıkan görsel başarıyla atandı";
                        } else {
                            $logs[] = "❌ Öne çıkan görsel atanamadı";
                        }
                    }
                    // Resim işleme tamamlandı mı kontrol et
                    $image_patterns = [
                        '/(src|data-src|srcset)=("|\')([^"\'>]*web\.archive\.org[^"\'>]+\.(jpg|jpeg|png|gif|webp|bmp|svg)[^"\'>]*)/i',
                        '/https?:\/\/web\.archive\.org\/[^"\'>\s]+\.(jpg|jpeg|png|gif|webp|bmp|svg)/i',
                    ];
                    $remaining_images = 0;
                    foreach ($image_patterns as $pattern) {
                        $remaining_images += preg_match_all($pattern, $updated_content, $matches);
                    }
                    
                    if ($updated_content !== $content) {
                        wp_update_post(array(
                            'ID' => $post->ID,
                            'post_content' => $updated_content
                        ));
                        $logs[] = "💾 Gönderi #{$post->ID} güncellendi";
                    } else {
                        $logs[] = "⏭️ Gönderi #{$post->ID} güncellenmedi (değişiklik yok)";
                    }
                    
                    // Sadece archive.org RESİMLERİ kalmadıysa işlenmiş olarak işaretle
                    if ($remaining_images == 0) {
                        update_post_meta($post->ID, '_archive_processed', current_time('mysql'));
                        $logs[] = "✅ Gönderi #{$post->ID}: Tüm archive.org resimleri başarıyla işlendi.";
                        $processed++;
                    } else {
                        $logs[] = "⚠️ Gönderi #{$post->ID}: Hala {$remaining_images} archive.org resmi kaldı, tekrar kuyruğa alınacak.";
                    }
                    $logs[] = "✅ Gönderi #{$post->ID} tamamlandı";
                }
            }
            $total_images = $this->count_archive_images();
            $current_progress = ($batch * $batch_size + $processed);
            $progress_percentage = min(100, round(($current_progress / max(1, $total_images)) * 100, 1));
            
            $logs[] = "📊 Batch İstatistikleri:";
            $logs[] = "   📝 İşlenen gönderi: " . $processed;
            $logs[] = "   🎯 Kalan gönderi: " . max(0, $total_images - $current_progress);
            $logs[] = "   📈 İlerleme: " . $progress_percentage . "%";
            
            // Tahmini kalan süre hesapla
            if ($batch > 0 && $processed > 0) {
                $avg_time_per_batch = 5; // Ortalama 5 saniye per batch
                $remaining_batches = ceil(($total_images - $current_progress) / $batch_size);
                $estimated_remaining_time = $remaining_batches * $avg_time_per_batch;
                if ($estimated_remaining_time > 60) {
                    $logs[] = "   ⏱️ Tahmini kalan süre: ~" . round($estimated_remaining_time / 60) . " dakika";
                } else {
                    $logs[] = "   ⏱️ Tahmini kalan süre: ~" . $estimated_remaining_time . " saniye";
                }
            }
            
            // Başarı oranını hesapla
            $success_rate = ($processed > 0) ? 100 : 0;
            if ($total_images > 0 && $processed > 0) {
                $success_rate = min(100, round(($processed / $total_images) * 100));
            }
            
            wp_send_json_success(array(
                'processed' => $processed,
                'total_images' => $total_images,
                'completed' => $completed,
                'logs' => $logs,
                'log_type' => 'info',
                'batch' => $batch,
                'progress' => $progress_percentage,
                'success_rate' => $success_rate
            ));
        } catch (Exception $e) {
            $logs[] = "❌ Kritik hata: " . $e->getMessage();
            wp_send_json_error(array(
                'message' => 'İşlem hatası: ' . $e->getMessage(),
                'logs' => $logs
            ));
        }
    }
    
    // Yeni: Hataları Exception yerine loglayan güvenli wrapper
    private function download_and_upload_image_safe($archive_url, $post_id, $timeout, &$logs, &$failed_images) {
        try {
            return $this->download_and_upload_image($archive_url, $post_id, $timeout);
        } catch (Exception $e) {
            $failed_images[] = "❌ Resim işlenemedi: " . basename($archive_url) . " - " . $e->getMessage();
            return false;
        }
    }
    
    private function download_and_upload_image($archive_url, $post_id, $timeout) {
        // URL'yi temizle ve doğrula
        $archive_url = trim($archive_url);
        
        // Resmi indir - daha güçlü ayarlar
        $response = wp_remote_get($archive_url, array(
            'timeout' => $timeout,
            'user-agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
            'sslverify' => false,
            'redirection' => 5,
            'httpversion' => '1.1',
            'blocking' => true
        ));
        
        if (is_wp_error($response)) {
            // İndirme başarısız - varsayılan resmi kullan
            $default_url = $this->get_default_image_url();
            if ($default_url) {
                return $default_url;
            }
            throw new Exception('Resim indirilemedi: ' . $response->get_error_message());
        }
        
        $response_code = wp_remote_retrieve_response_code($response);
        if ($response_code !== 200) {
            // HTTP hatası - varsayılan resmi kullan
            $default_url = $this->get_default_image_url();
            if ($default_url) {
                return $default_url;
            }
            throw new Exception('HTTP hatası: ' . $response_code);
        }
        
        $image_data = wp_remote_retrieve_body($response);
        $content_type = wp_remote_retrieve_header($response, 'content-type');
        
        if (empty($image_data)) {
            // Resim verisi boş - varsayılan resmi kullan
            $default_url = $this->get_default_image_url();
            if ($default_url) {
                return $default_url;
            }
            throw new Exception('Resim verisi boş');
        }
        
        // Resim boyutunu kontrol et (çok küçük resimler hatalı olabilir)
        $min_size = 500; // 500 byte minimum
        if (strlen($image_data) < $min_size) {
            // Çok küçük resim - varsayılan resmi kullan
            $default_url = $this->get_default_image_url();
            if ($default_url) {
                return $default_url;
            }
            throw new Exception('Resim çok küçük (' . strlen($image_data) . ' byte)');
        }
        
        // Content-type kontrolü
        if (empty($content_type) || strpos($content_type, 'image/') === false) {
            // Geçersiz content-type - varsayılan resmi kullan
            $default_url = $this->get_default_image_url();
            if ($default_url) {
                return $default_url;
            }
            throw new Exception('Geçersiz content-type: ' . $content_type);
        }
        
        // Dosya uzantısını belirle
        $extension = 'jpg'; // Varsayılan
        if (strpos($content_type, 'png') !== false) {
            $extension = 'png';
        } elseif (strpos($content_type, 'gif') !== false) {
            $extension = 'gif';
        } elseif (strpos($content_type, 'webp') !== false) {
            $extension = 'webp';
        } elseif (strpos($content_type, 'bmp') !== false) {
            $extension = 'bmp';
        } elseif (strpos($content_type, 'svg') !== false) {
            $extension = 'svg';
        }
        
        // Dosya adını oluştur - daha güvenli
        $safe_filename = sanitize_file_name(basename($archive_url));
        $safe_filename = preg_replace('/[^a-zA-Z0-9._-]/', '_', $safe_filename);
        $filename = $post_id . '_' . time() . '_' . substr(md5($archive_url), 0, 8) . '.' . $extension;
        
        // WordPress'e yükle
        $upload = wp_upload_bits($filename, null, $image_data);
        
        if ($upload['error']) {
            // Yükleme hatası - varsayılan resmi kullan
            $default_url = $this->get_default_image_url();
            if ($default_url) {
                return $default_url;
            }
            throw new Exception('Yükleme hatası: ' . $upload['error']);
        }
        
        // Medya kütüphanesine ekle
        $attachment_id = wp_insert_attachment(array(
            'post_title' => $safe_filename,
            'post_content' => 'Archive.org\'dan indirilen resim',
            'post_status' => 'inherit',
            'post_parent' => $post_id,
            'post_mime_type' => $content_type
        ), $upload['file'], $post_id);
        
        if (is_wp_error($attachment_id)) {
            // Medya ekleme hatası - varsayılan resmi kullan
            $default_url = $this->get_default_image_url();
            if ($default_url) {
                return $default_url;
            }
            throw new Exception('Medya ekleme hatası: ' . $attachment_id->get_error_message());
        }
        
        // Resim boyutlarını oluştur
        require_once(ABSPATH . 'wp-admin/includes/image.php');
        $attachment_data = wp_generate_attachment_metadata($attachment_id, $upload['file']);
        wp_update_attachment_metadata($attachment_id, $attachment_data);
        
        return $upload['url'];
    }
    
    private function download_and_attach_featured_image($image_url, $post_id, $timeout, &$logs) {
        // Resmi indir
        $response = wp_remote_get($image_url, array(
            'timeout' => $timeout,
            'user-agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        ));
        if (is_wp_error($response)) {
            $logs[] = '❌ Öne çıkan görsel indirilemedi: ' . $image_url;
            return false;
        }
        $image_data = wp_remote_retrieve_body($response);
        $content_type = wp_remote_retrieve_header($response, 'content-type');
        if (empty($image_data)) {
            $logs[] = '❌ Öne çıkan görsel verisi boş: ' . $image_url;
            return false;
        }
        // Dosya uzantısını belirle
        $extension = 'jpg';
        if (strpos($content_type, 'png') !== false) {
            $extension = 'png';
        } elseif (strpos($content_type, 'gif') !== false) {
            $extension = 'gif';
        } elseif (strpos($content_type, 'webp') !== false) {
            $extension = 'webp';
        }
        $filename = 'featured_' . $post_id . '_' . time() . '_' . rand(1000, 9999) . '.' . $extension;
        $upload = wp_upload_bits($filename, null, $image_data);
        if ($upload['error']) {
            $logs[] = '❌ Öne çıkan görsel yükleme hatası: ' . $upload['error'];
            return false;
        }
        // Medya kütüphanesine ekle
        $attachment_id = wp_insert_attachment(array(
            'post_title' => $filename,
            'post_content' => '',
            'post_status' => 'inherit',
            'post_parent' => $post_id,
            'post_mime_type' => $content_type
        ), $upload['file'], $post_id);
        if (is_wp_error($attachment_id)) {
            $logs[] = '❌ Öne çıkan görsel medya ekleme hatası: ' . $attachment_id->get_error_message();
            return false;
        }
        require_once(ABSPATH . 'wp-admin/includes/image.php');
        $attachment_data = wp_generate_attachment_metadata($attachment_id, $upload['file']);
        wp_update_attachment_metadata($attachment_id, $attachment_data);
        return $attachment_id;
    }
    
    private function count_archive_images() {
        global $wpdb;
        
        // Sadece archive.org RESİM linklerini içeren gönderileri say
        $count = $wpdb->get_var($wpdb->prepare("
            SELECT COUNT(*) 
            FROM {$wpdb->posts} 
            WHERE post_type = %s 
            AND post_status = %s 
            AND (post_content LIKE %s OR post_content LIKE %s)
        ", 'post', 'publish', '%web.archive.org%im_/%', '%web.archive.org%/im_/%'));
        
        return intval($count);
    }
    
    // Yeni: Detaylı archive.org link analizi
    private function get_detailed_archive_analysis() {
        global $wpdb;
        
        $posts = $wpdb->get_results($wpdb->prepare("
            SELECT ID, post_title, post_content 
            FROM {$wpdb->posts} 
            WHERE post_type = %s 
            AND post_status = %s 
            AND post_content LIKE %s
        ", 'post', 'publish', '%web.archive.org%'));
        
        $analysis = array();
        foreach ($posts as $post) {
            preg_match_all('/https?:\/\/web\.archive\.org\/[^"\'>\s]+/i', $post->post_content, $matches);
            if (!empty($matches[0])) {
                $analysis[] = array(
                    'id' => $post->ID,
                    'title' => $post->post_title,
                    'links' => $matches[0],
                    'count' => count($matches[0])
                );
            }
        }
        
        return $analysis;
    }
    
    private function count_internal_links() {
        global $wpdb;
        
        // Tüm archive.org linklerini içeren gönderileri say (resim + normal link)
        $count = $wpdb->get_var($wpdb->prepare("
            SELECT COUNT(*) 
            FROM {$wpdb->posts} 
            WHERE post_type = %s 
            AND post_status = %s 
            AND post_content LIKE %s
        ", 'post', 'publish', '%web.archive.org%'));
        
        return intval($count);
    }
    
    public function clean_internal_links() {
        // Nonce kontrolü
        if (!wp_verify_nonce($_POST['nonce'], 'archive_radar_nonce')) {
            wp_die('Güvenlik hatası');
        }
        $logs = array();
        $processed = 0;
        try {
            // Archive.org linklerini içeren gönderileri bul
            $posts = get_posts(array(
                'post_type' => 'post',
                'post_status' => 'publish',
                'posts_per_page' => -1,
                'meta_query' => array(
                    array(
                        'key' => '_links_cleaned',
                        'compare' => 'NOT EXISTS'
                    )
                )
            ));
            
            $logs[] = "🔍 " . count($posts) . " gönderi analiz ediliyor...";
            
            foreach ($posts as $post) {
                $content = $post->post_content;
                $logs[] = "📝 Gönderi #{$post->ID}: {$post->post_title}";
                
                // Önce kaç archive.org linki var say
                preg_match_all('/https?:\/\/web\.archive\.org/i', $content, $matches);
                $before_count = count($matches[0]);
                
                $updated_content = $this->clean_all_archive_links($post, $content, $logs);
                
                // Sonra kaç archive.org linki kaldı say
                preg_match_all('/https?:\/\/web\.archive\.org/i', $updated_content, $matches);
                $after_count = count($matches[0]);
                
                if ($updated_content !== $content) {
                    wp_update_post(array(
                        'ID' => $post->ID,
                        'post_content' => $updated_content
                    ));
                    $logs[] = "✅ Gönderi #{$post->ID}: {$before_count} → {$after_count} link (Temizlendi)";
                    $processed++;
                } else {
                    $logs[] = "⏭️ Gönderi #{$post->ID}: Değişiklik yok";
                }
                
                // İşlendi olarak işaretle
                update_post_meta($post->ID, '_links_cleaned', current_time('mysql'));
            }
            
            $logs[] = "🎉 İşlem tamamlandı! {$processed} gönderi güncellendi.";
            
            wp_send_json_success(array(
                'processed' => $processed,
                'logs' => $logs
            ));
        } catch (Exception $e) {
            wp_send_json_error('İşlem hatası: ' . $e->getMessage());
        }
    }

    // Gelişmiş: Tüm archive.org linklerini (her attribute ve içerikte) temizle
    private function clean_all_archive_links($post, $content, &$logs) {
        $updated_content = $content;
        $total_cleaned = 0;
        $iteration = 0;
        $max_iterations = 10; // Daha fazla iterasyon
        $broken_cleaned = 0;

        // 0. Satır sonu ve boşluk normalize: href içinde bölünmüş archive.org linklerini tek satıra çek
        $updated_content = preg_replace_callback(
            '/href=(["\"])https?:\/\/web\.archive\.org\/web\/[0-9a-zA-Z_\n\r]+\/[^"]*?\1/im',
            function($matches) {
                return preg_replace('/\s+/', '', $matches[0]);
            },
            $updated_content
        );

        // 0.5. Satır sonu ile bölünmüş archive.org linklerini normalize et (href dışında da)
        $updated_content = preg_replace_callback(
            '/https?:\/\/w\s*\n\s*eb\.archive\.org\/web\/[0-9a-zA-Z_\n\r]+\/[^"\'>\s]*/im',
            function($matches) {
                return preg_replace('/\s+/', '', $matches[0]);
            },
            $updated_content
        );

        // 0.7. Kırık/tamamlanmamış archive.org linklerini tamamen sil (orijinal adresi olmayanlar)
        // Yani: https://web.archive.org/web/201310250 gibi, devamında http/https olmayanlar
        $updated_content = preg_replace_callback(
            '/https?:\/\/web\.archive\.org\/web\/[0-9a-zA-Z_]+(?!\/https?:\/\/)[^"\'>\s]*/i',
            function($matches) use (&$broken_cleaned, &$logs, $post) {
                $broken_cleaned++;
                $logs[] = "🗑️ Gönderi #{$post->ID}: Kırık archive.org linki silindi: " . $matches[0];
                return '';
            },
            $updated_content
        );

        // 1. HTML entity decode (özellikle &amp; gibi karakterler için)
        if (function_exists('html_entity_decode')) {
            $updated_content = html_entity_decode($updated_content, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        }

        // 2. Satır sonu ve boşlukları normalize et (archive.org linklerinde)
        $updated_content = preg_replace_callback(
            '/https?:\/\/web\.archive\.org\/web\/[0-9a-zA-Z_\n\r]+\/[^"]+/im',
            function($matches) {
                return str_replace(["\n", "\r", " "], '', $matches[0]);
            },
            $updated_content
        );

        do {
            $iteration++;
            $cleaned_this_iteration = 0;
            $archive_patterns = [
                '/https?:\/\/web\.archive\.org\/web\/[0-9a-zA-Z_]+\/(https?:\/\/[^"\'>\s]+)/i',
                '/https?:\/\/web\.archive\.org\/web\/[0-9a-zA-Z_]+\/(.+?)(?=["\'>\s])/i',
            ];
            foreach ($archive_patterns as $pattern) {
                $updated_content = preg_replace_callback($pattern, function($matches) use (&$logs, &$total_cleaned, &$cleaned_this_iteration, $iteration) {
                    $original_url = $matches[0];
                    $extracted_url = isset($matches[1]) ? $matches[1] : '';
                    $extracted_url = urldecode($extracted_url);
                    if (strpos($extracted_url, 'http') !== 0) {
                        $extracted_url = $original_url;
                    }
                    $logs[] = "🔗 Archive.org link temizlendi (iterasyon {$iteration}): " . $original_url . " → " . $extracted_url;
                    $total_cleaned++;
                    $cleaned_this_iteration++;
                    return $extracted_url;
                }, $updated_content);
            }
            $srcset_pattern = '/(srcset|data-srcset)=["\']([^"\']+)["\']/i';
            $updated_content = preg_replace_callback($srcset_pattern, function($matches) use (&$logs, &$total_cleaned, &$cleaned_this_iteration, $iteration) {
                $srcset_content = $matches[2];
                $cleaned_srcset = preg_replace('/https?:\/\/web\.archive\.org\/web\/[0-9a-zA-Z_]+\/(.+?)(?=[,\s])/i', '$1', $srcset_content);
                if ($cleaned_srcset !== $srcset_content) {
                    $logs[] = "🔗 Srcset archive.org temizlendi (iterasyon {$iteration}): " . $srcset_content . " → " . $cleaned_srcset;
                    $total_cleaned++;
                    $cleaned_this_iteration++;
                }
                return $matches[1] . '="' . $cleaned_srcset . '"';
            }, $updated_content);
            $style_pattern = '/style=["\']([^"\']*web\.archive\.org[^"\']+)["\']/i';
            $updated_content = preg_replace_callback($style_pattern, function($matches) use (&$logs, &$total_cleaned, &$cleaned_this_iteration, $iteration) {
                $style_content = $matches[1];
                $cleaned_style = preg_replace('/https?:\/\/web\.archive\.org\/web\/[0-9a-zA-Z_]+\/(.+?)(?=[;\s])/i', '$1', $style_content);
                if ($cleaned_style !== $style_content) {
                    $logs[] = "🔗 Style archive.org temizlendi (iterasyon {$iteration}): " . $style_content . " → " . $cleaned_style;
                    $total_cleaned++;
                    $cleaned_this_iteration++;
                }
                return 'style="' . $cleaned_style . '"';
            }, $updated_content);
            if ($cleaned_this_iteration == 0 && $iteration > 5) {
                preg_match_all('/https?:\/\/web\.archive\.org\/[^"\'>\s]+/i', $updated_content, $remaining_matches);
                if (!empty($remaining_matches[0])) {
                    $logs[] = "🗑️ Gönderi #{$post->ID}: Kalan archive.org linkleri siliniyor: " . implode(', ', $remaining_matches[0]);
                }
                $updated_content = preg_replace('/https?:\/\/web\.archive\.org\/[^"\'>\s]+/i', '', $updated_content);
                $cleaned_this_iteration = 1;
            }
        } while ($cleaned_this_iteration > 0 && $iteration < $max_iterations);
        $remaining_pattern = '/https?:\/\/web\.archive\.org/i';
        $remaining_count = preg_match_all($remaining_pattern, $updated_content, $matches);
        if ($remaining_count > 0) {
            $logs[] = "⚠️ Gönderi #{$post->ID}: Hala {$remaining_count} archive.org linki kaldı, tekrar kuyruğa alınacak";
        } else {
            $logs[] = "✅ Gönderi #{$post->ID}: Tüm archive.org linkleri başarıyla temizlendi ({$total_cleaned} link, {$broken_cleaned} kırık link)";
        }
        return $updated_content;
    }
    
    private function extract_original_url($archive_url) {
        // https://web.archive.org/web/20231201123456/http://example.com/page
        // Buradan http://example.com/page kısmını çıkar
        if (preg_match('/https:\/\/web\.archive\.org\/web\/\d+\/(.+)/i', $archive_url, $matches)) {
            return $matches[1];
        }
        return false;
    }
    
    public function bulk_find_replace() {
        // Nonce kontrolü
        if (!wp_verify_nonce($_POST['nonce'], 'archive_radar_nonce')) {
            wp_die('Güvenlik hatası');
        }
        
        $find_text = sanitize_text_field($_POST['find_text']);
        $replace_text = sanitize_text_field($_POST['replace_text']);
        $replace_posts = $_POST['replace_posts'] === 'true';
        $replace_pages = $_POST['replace_pages'] === 'true';
        $replace_comments = $_POST['replace_comments'] === 'true';
        
        if (empty($find_text)) {
            wp_send_json_error('Bul metni boş olamaz');
        }
        
        $logs = array();
        $processed = 0;
        
        try {
            global $wpdb;
            
            // Yazıları güncelle
            if ($replace_posts) {
                $result = $wpdb->query($wpdb->prepare("
                    UPDATE {$wpdb->posts} 
                    SET post_content = REPLACE(post_content, %s, %s),
                        post_title = REPLACE(post_title, %s, %s)
                    WHERE post_type = 'post' AND post_status = 'publish'
                ", $find_text, $replace_text, $find_text, $replace_text));
                
                if ($result !== false) {
                    $processed += $result;
                    $logs[] = "Yazılar güncellendi: {$result} kayıt";
                }
            }
            
            // Sayfaları güncelle
            if ($replace_pages) {
                $result = $wpdb->query($wpdb->prepare("
                    UPDATE {$wpdb->posts} 
                    SET post_content = REPLACE(post_content, %s, %s),
                        post_title = REPLACE(post_title, %s, %s)
                    WHERE post_type = 'page' AND post_status = 'publish'
                ", $find_text, $replace_text, $find_text, $replace_text));
                
                if ($result !== false) {
                    $processed += $result;
                    $logs[] = "Sayfalar güncellendi: {$result} kayıt";
                }
            }
            
            // Yorumları güncelle
            if ($replace_comments) {
                $result = $wpdb->query($wpdb->prepare("
                    UPDATE {$wpdb->comments} 
                    SET comment_content = REPLACE(comment_content, %s, %s),
                        comment_author = REPLACE(comment_author, %s, %s)
                    WHERE comment_approved = '1'
                ", $find_text, $replace_text, $find_text, $replace_text));
                
                if ($result !== false) {
                    $processed += $result;
                    $logs[] = "Yorumlar güncellendi: {$result} kayıt";
                }
            }
            
            wp_send_json_success(array(
                'processed' => $processed,
                'logs' => $logs
            ));
            
        } catch (Exception $e) {
            wp_send_json_error('İşlem hatası: ' . $e->getMessage());
        }
    }

    public function reset_processing() {
        // Nonce kontrolü
        if (!wp_verify_nonce($_POST['nonce'], 'archive_radar_nonce')) {
            wp_die('Güvenlik hatası');
        }
        
        // İşlem durumunu sıfırla
        $this->reset_processing_state();
        
        wp_send_json_success(array(
            'message' => 'İşlem durumu sıfırlandı'
        ));
    }

    private function reset_processing_state() {
        global $wpdb;
        
        // Tüm işlenmiş gönderilerin meta verilerini temizle
        $wpdb->query("
            DELETE FROM {$wpdb->postmeta} 
            WHERE meta_key = '_archive_processed' 
            OR meta_key = '_links_cleaned'
            OR meta_key LIKE '_processed_%'
            OR meta_key LIKE '_archive_%'
            OR meta_key LIKE '_featured_%'
        ");
        
        // İstatistikleri sıfırla
        wp_cache_flush();
        
        // Tüm gönderileri yeniden işlenebilir hale getir
        $wpdb->query("
            UPDATE {$wpdb->posts} 
            SET post_content = post_content 
            WHERE post_type = 'post' 
            AND post_status = 'publish'
        ");
        
        // Öne çıkan görselleri de temizle
        $wpdb->query("
            UPDATE {$wpdb->posts} 
            SET post_content = post_content 
            WHERE post_type = 'attachment' 
            AND post_parent IN (
                SELECT ID FROM {$wpdb->posts} 
                WHERE post_type = 'post' 
                AND post_status = 'publish'
            )
        ");
    }

    public function fix_post_slugs() {
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Yetkiniz yok.');
        }
        global $wpdb;
        $args = [
            'post_type' => 'post',
            'post_status' => ['publish', 'draft', 'pending', 'future', 'private'],
            'posts_per_page' => -1,
            'fields' => 'ids',
        ];
        $post_ids = get_posts($args);
        $logs = [];
        foreach ($post_ids as $post_id) {
            $post = get_post($post_id);
            $title = $post->post_title;
            $old_slug = $post->post_name;
            $new_slug = sanitize_title($title);
            if ($old_slug !== $new_slug && $new_slug) {
                // Benzersiz yap
                $unique_slug = wp_unique_post_slug($new_slug, $post_id, $post->post_status, $post->post_type, $post->post_parent);
                wp_update_post([
                    'ID' => $post_id,
                    'post_name' => $unique_slug,
                ]);
                $logs[] = "#{$post_id}: '$old_slug' → '$unique_slug'";
            } else {
                $logs[] = "#{$post_id}: Zaten doğru veya boş başlık.";
            }
        }
        wp_send_json_success(['logs' => $logs]);
    }

    public function clear_post_excerpts() {
        // Nonce kontrolü
        if (!wp_verify_nonce($_POST['nonce'], 'archive_radar_nonce')) {
            wp_die('Güvenlik hatası');
        }
        $logs = array();
        $processed = 0;
        try {
            global $wpdb;
            $posts = $wpdb->get_results($wpdb->prepare("SELECT ID, post_title, post_excerpt FROM {$wpdb->posts} WHERE post_type = %s AND post_status = %s AND post_excerpt != ''", 'post', 'publish'));
            $logs[] = '🔍 ' . count($posts) . ' yazı özetli olarak bulundu.';
            foreach ($posts as $post) {
                $wpdb->update(
                    $wpdb->posts,
                    array('post_excerpt' => ''),
                    array('ID' => $post->ID)
                );
                $logs[] = "🧹 Gönderi #{$post->ID} özet temizlendi.";
                $processed++;
            }
            $logs[] = "🎉 İşlem tamamlandı! {$processed} yazının özeti temizlendi.";
            wp_send_json_success(array(
                'processed' => $processed,
                'logs' => $logs
            ));
        } catch (Exception $e) {
            wp_send_json_error('İşlem hatası: ' . $e->getMessage());
        }
    }
}

// Eklentiyi başlat
new ArchiveRadarImageProcessor(); 